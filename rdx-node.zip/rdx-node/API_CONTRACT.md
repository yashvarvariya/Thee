# RDX Node Bot ↔ Central API Contract

This document specifies the HTTPS/WSS contract that the **Central RDX
Control API** must implement for this Node Bot to work. The Node Bot makes
no assumptions beyond what's documented here.

All requests/responses are JSON. All endpoints are versioned under `/api/v1`.
`protocol_version` is included in every request body for future compatibility.

---

## Authentication

- **Pairing** (`POST /nodes/pair`): authenticated by the one-time `pairing_key`
  in the request body. No bearer token yet exists at this point.
- **All other endpoints**: authenticated via `Authorization: Bearer <node_token>`,
  where `node_token` is the permanent credential returned by a successful pair.

The Node Bot rejects plain `http://` for `CENTRAL_URL` unless
`ALLOW_INSECURE_HTTP=true` is explicitly set (local development only).

---

## 1. `POST /api/v1/nodes/pair`

Called once, when an admin runs `/pair` on the Node Bot and submits a
pairing key.

### Request

```json
{
  "protocol_version": "1.0",
  "node_id": "RDX-NODE-7F3A92",
  "pairing_key": "RDX-7K4P-92XM",
  "node_name": "RDX-NODE1",
  "host_info": {
    "os_name": "Ubuntu",
    "os_version": "22.04",
    "kernel_version": "5.15.0-91-generic",
    "cpu_cores": 12,
    "cpu_usage_percent": 4.2,
    "ram_total_mb": 38912,
    "ram_used_mb": 2048,
    "ram_available_mb": 36864,
    "disk_total_gb": 200.0,
    "disk_used_gb": 12.5,
    "disk_available_gb": 187.5
  },
  "docker_status": {
    "available": true,
    "daemon_running": true,
    "version": "27.3.1"
  }
}
```

### Response — 200 OK

```json
{
  "node_id": "RDX-NODE-7F3A92",
  "node_token": "<opaque permanent credential>",
  "heartbeat_interval": 30,
  "configuration": {}
}
```

The pairing key becomes invalid immediately after a successful pairing
(single use).

### Error responses

| Status | Meaning                                   |
|--------|--------------------------------------------|
| 401    | Invalid or expired pairing key              |
| 409    | This `node_id` is already paired            |
| 5xx    | Central API internal error                  |

The Node Bot never surfaces raw server error bodies to Discord — only a
generic, safe message per status code.

---

## 2. `POST /api/v1/nodes/heartbeat`

Sent periodically (default every 30s, or whatever `heartbeat_interval` was
returned at pairing time). Requires `Authorization: Bearer <node_token>`.

### Request

```json
{
  "protocol_version": "1.0",
  "node_id": "RDX-NODE-7F3A92",
  "timestamp": "2026-08-21T12:00:00+00:00",
  "cpu_usage": 18.4,
  "cpu_cores": 12,
  "ram_total": 38912,
  "ram_used": 12288,
  "disk_total": 100,
  "disk_used": 40,
  "docker_status": "online",
  "container_count": 5,
  "os": "Ubuntu",
  "agent_version": "1.0.0"
}
```

### Response — 200 OK

```json
{ "acknowledged": true }
```

If the Central API is unreachable, the Node Bot keeps running locally,
retries on the same interval, and shows `🔴 Central: OFFLINE` in `/status`.

---

## 3. `POST /api/v1/nodes/unpair`

Requires `Authorization: Bearer <node_token>`. Called when an admin
confirms `/unpair`. The Node Bot clears its local token regardless of
whether this call succeeds.

### Request

```json
{ "protocol_version": "1.0", "node_id": "RDX-NODE-7F3A92" }
```

### Response

`200 OK` or `204 No Content`.

---

## 4. WebSocket `wss://.../api/v1/nodes/ws`

Used for real-time commands from Central → Node. Connected with
`Authorization: Bearer <node_token>` as a connection header.

On connect, the Node Bot sends:

```json
{ "type": "hello", "node_id": "RDX-NODE-7F3A92", "protocol_version": "1.0" }
```

### Reconnect behavior

If the connection drops for any reason, the Node Bot reconnects
automatically using exponential backoff: `1s, 2s, 4s, 8s, 16s, 30s` (capped).
Re-pairing is never required — the existing `node_token` is reused.

### Command format (Central → Node)

```json
{
  "type": "docker.create",
  "request_id": "a1b2c3d4",
  "payload": {
    "name": "user-vps-123",
    "image": "itzg/minecraft-server",
    "cpu": 2,
    "ram": 4096,
    "disk": 20,
    "env": { "EULA": "TRUE" },
    "ports": { "25565/tcp": 25565 }
  }
}
```

### Result format (Node → Central)

```json
{
  "type": "docker.create.result",
  "request_id": "a1b2c3d4",
  "result": {
    "ok": true,
    "data": { "id": "a3f9c2", "name": "user-vps-123", "status": "created" }
  }
}
```

On failure:

```json
{
  "type": "docker.create.result",
  "request_id": "a1b2c3d4",
  "result": {
    "ok": false,
    "error": "validation_error",
    "detail": "Image reference not allowed: some/untrusted-image"
  }
}
```

### Supported command types

| Command               | Alias           | Payload fields                                              |
|------------------------|-----------------|---------------------------------------------------------------|
| `GET_NODE_STATUS`      | `docker.status` | (none)                                                        |
| `GET_NODE_STATS`       | —               | (none)                                                        |
| `LIST_CONTAINERS`      | `docker.list`   | (none)                                                        |
| `CREATE_CONTAINER`     | `docker.create` | `name, image, cpu, ram, disk, env?, ports?`                   |
| `START_CONTAINER`      | `docker.start`  | `container_id`                                                |
| `STOP_CONTAINER`       | `docker.stop`   | `container_id, timeout?`                                      |
| `RESTART_CONTAINER`    | `docker.restart`| `container_id, timeout?`                                      |
| `DELETE_CONTAINER`     | `docker.delete` | `container_id, force?`                                        |
| `GET_CONTAINER_INFO`   | `docker.inspect`| `container_id`                                                 |
| `GET_CONTAINER_LOGS`   | `docker.logs`   | `container_id, tail?`                                          |
| `GET_CONTAINER_STATS`  | `docker.stats`  | `container_id`                                                 |

Any command type not in this table is rejected with
`{"ok": false, "error": "unsupported_command"}`. The Node Bot never executes
arbitrary shell commands — this table is the complete set of operations it
will ever perform.

### Error codes (result.error)

| Code                 | Meaning                                             |
|----------------------|------------------------------------------------------|
| `unsupported_command`| Command type not recognized                          |
| `invalid_payload`    | `payload` was not a JSON object                       |
| `validation_error`   | Payload failed field-level validation                 |
| `internal_error`     | Unexpected error on the node (Docker error, etc.)     |

---

## Versioning

Every request includes `protocol_version` (currently `"1.0"`). The Central
API should reject requests with an incompatible major version rather than
guessing at a schema.
