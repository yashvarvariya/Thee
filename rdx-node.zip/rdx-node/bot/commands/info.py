"""
/info command - shows detailed host information: OS, CPU, RAM, Disk,
Docker, Node ID, agent version.
"""

from __future__ import annotations

import discord
from discord import app_commands

from ..services.heartbeat import AGENT_VERSION
from ..services.system_info import get_system_snapshot


def register(tree: app_commands.CommandTree, bot_context) -> None:
    @tree.command(name="info", description="Show detailed information about this node's host")
    async def info_command(interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)

        snapshot = get_system_snapshot()
        docker_status = bot_context.docker_manager.docker_status()

        embed = discord.Embed(title="RDX Node Info", color=discord.Color.dark_teal())
        embed.add_field(name="Node ID", value=bot_context.node_state.node_id, inline=False)
        embed.add_field(name="OS", value=f"{snapshot.os_name} {snapshot.os_version}", inline=True)
        embed.add_field(name="Kernel", value=snapshot.kernel_version, inline=True)
        embed.add_field(name="Agent Version", value=AGENT_VERSION, inline=True)
        embed.add_field(name="CPU", value=f"{snapshot.cpu_cores} cores", inline=True)
        embed.add_field(name="RAM", value=f"{snapshot.ram_total_mb / 1024:.1f} GB total", inline=True)
        embed.add_field(name="Disk", value=f"{snapshot.disk_total_gb:.0f} GB total", inline=True)
        embed.add_field(
            name="Docker",
            value=(docker_status.version or "not detected") if docker_status.available else "unavailable",
            inline=True,
        )

        await interaction.followup.send(embed=embed, ephemeral=True)
