"""
/pair command.

Admin-only. Shows a Discord modal to collect the one-time pairing key,
never echoes it back, and never logs it. Delegates the actual handshake to
bot.services.pairing.pair_node.
"""

from __future__ import annotations

import logging

import discord
from discord import app_commands

from ..services.pairing import pair_node, PairingError

logger = logging.getLogger("rdx_node.commands.pair")


class PairingModal(discord.ui.Modal, title="RDX Node Pairing"):
    pairing_key = discord.ui.TextInput(
        label="Pairing Key",
        placeholder="Enter the one-time pairing key from the Central Bot",
        required=True,
        max_length=128,
    )

    def __init__(self, bot_context):
        super().__init__()
        self.bot_context = bot_context

    async def on_submit(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)

        ctx = self.bot_context
        # The pairing key lives only in this local variable and inside
        # pair_node()'s single request body - it is never logged.
        key_value = str(self.pairing_key.value)

        try:
            result = await pair_node(
                pairing_key=key_value,
                node_state=ctx.node_state,
                central_client=ctx.central_client,
                docker_manager=ctx.docker_manager,
                node_name=ctx.settings.node_name,
            )
        except PairingError as exc:
            await interaction.followup.send(f"❌ Pairing failed\n\n{exc}", ephemeral=True)
            return

        if not result.success:
            await interaction.followup.send(
                f"❌ Pairing failed\n\nInvalid or expired pairing key.\n({result.message})",
                ephemeral=True,
            )
            return

        # Successful pairing: start the heartbeat + command loop.
        await ctx.on_paired(heartbeat_interval=result.heartbeat_interval or ctx.settings.heartbeat_interval_seconds)

        docker_status = ctx.docker_manager.docker_status()
        from ..services.system_info import get_system_snapshot

        snapshot = get_system_snapshot()

        embed = discord.Embed(title="✅ Node Paired", color=discord.Color.green())
        embed.add_field(name="Node", value=ctx.node_state.node_id, inline=False)
        embed.add_field(name="Status", value="🟢 ONLINE", inline=True)
        embed.add_field(name="Docker", value="✅ Ready" if docker_status.daemon_running else "❌ Unavailable", inline=True)
        embed.add_field(name="CPU", value=f"{snapshot.cpu_cores} cores", inline=True)
        embed.add_field(name="RAM", value=f"{snapshot.ram_total_mb / 1024:.1f} GB", inline=True)

        await interaction.followup.send(embed=embed, ephemeral=True)


def register(tree: app_commands.CommandTree, bot_context) -> None:
    @tree.command(name="pair", description="Pair this node with the Central RDX Control API")
    async def pair_command(interaction: discord.Interaction) -> None:
        if not bot_context.is_admin(interaction.user.id):
            await interaction.response.send_message("You are not authorized to use this command.", ephemeral=True)
            return

        if bot_context.node_state.is_paired:
            await interaction.response.send_message(
                "This node is already paired. Use /unpair first if you want to re-pair.",
                ephemeral=True,
            )
            return

        await interaction.response.send_modal(PairingModal(bot_context))
