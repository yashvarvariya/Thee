"""
/status command - shows local node status: Node ID, CPU, RAM, Docker,
and whether the WebSocket connection to Central is currently up.
"""

from __future__ import annotations

import discord
from discord import app_commands

from ..services.system_info import get_system_snapshot


def register(tree: app_commands.CommandTree, bot_context) -> None:
    @tree.command(name="status", description="Show this node's current status")
    async def status_command(interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)

        snapshot = get_system_snapshot()
        docker_status = bot_context.docker_manager.docker_status()
        central_state = bot_context.central_connection_state  # "connected" | "connecting" | "disconnected"

        emoji = "🟢" if bot_context.node_state.is_paired and central_state == "connected" else "🔴"
        embed = discord.Embed(title=f"{emoji} RDX Node", color=discord.Color.blurple())
        embed.add_field(name="Node ID", value=bot_context.node_state.node_id, inline=False)
        embed.add_field(name="CPU", value=f"{snapshot.cpu_cores} cores ({snapshot.cpu_usage_percent:.0f}%)", inline=True)
        embed.add_field(
            name="RAM",
            value=f"{snapshot.ram_used_mb / 1024:.1f} / {snapshot.ram_total_mb / 1024:.1f} GB",
            inline=True,
        )
        embed.add_field(
            name="Disk",
            value=f"{snapshot.disk_used_gb:.0f} / {snapshot.disk_total_gb:.0f} GB",
            inline=True,
        )
        embed.add_field(name="Docker", value="ONLINE" if docker_status.daemon_running else "OFFLINE", inline=True)
        embed.add_field(
            name="Central",
            value="CONNECTED" if central_state == "connected" else central_state.upper(),
            inline=True,
        )
        embed.add_field(name="Paired", value="Yes" if bot_context.node_state.is_paired else "No (waiting)", inline=True)

        await interaction.followup.send(embed=embed, ephemeral=True)
