"""
/unpair command - admin only. Asks for confirmation before revoking the
local node token and returning the node to a waiting-for-pairing state.
"""

from __future__ import annotations

import discord
from discord import app_commands

from ..services.pairing import unpair_node


class ConfirmUnpairView(discord.ui.View):
    def __init__(self, bot_context, timeout: float = 30.0):
        super().__init__(timeout=timeout)
        self.bot_context = bot_context

    @discord.ui.button(label="Confirm Unpair", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        await unpair_node(node_state=self.bot_context.node_state, central_client=self.bot_context.central_client)
        await self.bot_context.on_unpaired()
        await interaction.followup.send(
            "✅ Node unpaired. It is now waiting for a new /pair.", ephemeral=True
        )
        self.stop()

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.send_message("Unpair cancelled.", ephemeral=True)
        self.stop()


def register(tree: app_commands.CommandTree, bot_context) -> None:
    @tree.command(name="unpair", description="Unpair this node from the Central RDX Control API")
    async def unpair_command(interaction: discord.Interaction) -> None:
        if not bot_context.is_admin(interaction.user.id):
            await interaction.response.send_message("You are not authorized to use this command.", ephemeral=True)
            return

        if not bot_context.node_state.is_paired:
            await interaction.response.send_message("This node is not currently paired.", ephemeral=True)
            return

        await interaction.response.send_message(
            "⚠️ This will disconnect the node from the Central API and clear its local credential. "
            "Are you sure?",
            view=ConfirmUnpairView(bot_context),
            ephemeral=True,
        )
