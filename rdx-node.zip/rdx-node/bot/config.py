"""
Configuration loading for the RDX Node Bot.

Reads settings from environment variables (populated from a local .env file
via python-dotenv). NODE_ID and NODE_TOKEN are persisted locally by the
node_identity / pairing services after first pairing and are re-read here
on every restart.
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

# Base directory of the project (rdx-node/)
BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_DIR = BASE_DIR / "config"
ENV_PATH = BASE_DIR / ".env"

CONFIG_DIR.mkdir(parents=True, exist_ok=True)

load_dotenv(dotenv_path=ENV_PATH)


def _bool_env(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in ("1", "true", "yes", "on")


def _int_env(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None or value.strip() == "":
        return default
    try:
        return int(value)
    except ValueError:
        return default


@dataclass
class Settings:
    central_url: str = field(default_factory=lambda: os.getenv("CENTRAL_URL", "").rstrip("/"))
    discord_token: str = field(default_factory=lambda: os.getenv("DISCORD_TOKEN", ""))
    admin_user_ids: set[int] = field(default_factory=set)
    node_name: str = field(default_factory=lambda: os.getenv("NODE_NAME", "RDX-NODE"))
    log_level: str = field(default_factory=lambda: os.getenv("LOG_LEVEL", "INFO").upper())
    allow_insecure_http: bool = field(default_factory=lambda: _bool_env("ALLOW_INSECURE_HTTP", False))
    heartbeat_interval_seconds: int = field(default_factory=lambda: _int_env("HEARTBEAT_INTERVAL_SECONDS", 30))

    def __post_init__(self) -> None:
        raw_admins = os.getenv("ADMIN_USER_IDS", "")
        ids: set[int] = set()
        for part in raw_admins.split(","):
            part = part.strip()
            if part.isdigit():
                ids.add(int(part))
        self.admin_user_ids = ids

    def validate(self) -> list[str]:
        """Return a list of human-readable configuration problems (empty if OK)."""
        problems: list[str] = []
        if not self.central_url:
            problems.append("CENTRAL_URL is not set.")
        elif self.central_url.startswith("http://") and not self.allow_insecure_http:
            problems.append(
                "CENTRAL_URL uses insecure HTTP. Set ALLOW_INSECURE_HTTP=true for local "
                "development only, or use HTTPS in production."
            )
        elif not (self.central_url.startswith("https://") or self.central_url.startswith("http://")):
            problems.append("CENTRAL_URL must start with https:// (or http:// for local dev).")

        if not self.discord_token:
            problems.append("DISCORD_TOKEN is not set.")

        if not self.admin_user_ids:
            problems.append(
                "ADMIN_USER_IDS is empty - no one will be able to run /pair or /unpair."
            )

        return problems

    @property
    def ws_url(self) -> str:
        """Derive the WebSocket URL from CENTRAL_URL."""
        if self.central_url.startswith("https://"):
            base = "wss://" + self.central_url[len("https://"):]
        elif self.central_url.startswith("http://"):
            base = "ws://" + self.central_url[len("http://"):]
        else:
            base = self.central_url
        return base + "/api/v1/nodes/ws"


settings = Settings()


def fail_fast_if_invalid() -> None:
    problems = settings.validate()
    if problems:
        print("RDX Node Bot configuration problems detected:", file=sys.stderr)
        for p in problems:
            print(f"  - {p}", file=sys.stderr)
        print("\nEdit your .env file (see .env.example) and restart.", file=sys.stderr)
        sys.exit(1)
