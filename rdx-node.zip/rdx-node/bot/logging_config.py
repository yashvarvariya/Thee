"""
Safe logging setup for the RDX Node Bot.

Guarantees:
  - Pairing keys, node tokens, and API credentials are never written to logs,
    even if a caller accidentally includes them in a log message.
  - A rotating file handler keeps local logs bounded in size.

This is defense in depth: services should never pass secrets into log
messages in the first place (see docstrings in pairing.py / central_client.py),
but this filter catches mistakes before they reach disk or stdout.
"""

from __future__ import annotations

import logging
import logging.handlers
import re
from pathlib import Path

REDACTED = "[REDACTED]"

# Patterns that indicate a secret value follows a known key name, e.g.
# node_token=abc123, "pairing_key": "XXXX-YYYY", Authorization: Bearer <token>
_SECRET_PATTERNS = [
    re.compile(r"(pairing[_-]?key\"?\s*[:=]\s*\"?)([^\s\"',}]+)", re.IGNORECASE),
    re.compile(r"(node[_-]?token\"?\s*[:=]\s*\"?)([^\s\"',}]+)", re.IGNORECASE),
    re.compile(r"(authorization\"?\s*[:=]\s*\"?bearer\s+)([^\s\"',}]+)", re.IGNORECASE),
    re.compile(r"(password\"?\s*[:=]\s*\"?)([^\s\"',}]+)", re.IGNORECASE),
    re.compile(r"(api[_-]?key\"?\s*[:=]\s*\"?)([^\s\"',}]+)", re.IGNORECASE),
]


class RedactSecretsFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            msg = record.getMessage()
        except Exception:
            return True

        redacted_msg = msg
        for pattern in _SECRET_PATTERNS:
            redacted_msg = pattern.sub(lambda m: m.group(1) + REDACTED, redacted_msg)

        if redacted_msg != msg:
            record.msg = redacted_msg
            record.args = ()

        return True


def setup_logging(log_level: str, log_dir: Path) -> logging.Logger:
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / "rdx-node.log"

    logger = logging.getLogger("rdx_node")
    logger.setLevel(log_level)
    logger.handlers.clear()

    formatter = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    )

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    console_handler.addFilter(RedactSecretsFilter())
    logger.addHandler(console_handler)

    file_handler = logging.handlers.RotatingFileHandler(
        log_path, maxBytes=5 * 1024 * 1024, backupCount=3
    )
    file_handler.setFormatter(formatter)
    file_handler.addFilter(RedactSecretsFilter())
    logger.addHandler(file_handler)

    return logger
