"""
RDX Node Bot - main entry point.

Startup sequence (matches project spec):
  1. Load config, fail fast if invalid.
  2. Load/create stable Node ID, load stored token (if previously paired).
  3. Detect Docker.
  4. Start Discord bot with /pair /status /info /unpair commands.
  5. If already paired, start heartbeat + WebSocket command loop
     immediately (no /pair required after restart).
  6. If not paired, wait for an admin to run /pair.
"""

from __future__ import annotations

import asyncio
import logging
import sys

import discord
from discord import app_commands

from . import config as config_module
from .logging_config import setup_logging
from .services.central_client import CentralClient
from .services.command_dispatcher import CommandDispatcher
from .services.docker_manager import DockerManager
from .services.heartbeat import HeartbeatService
from .services.node_identity import NodeState

from .commands import pair as pair_cmd
from .commands import status as status_cmd
from .commands import info as info_cmd
from .commands import unpair as unpair_cmd

config_module.fail_fast_if_invalid()
settings = config_module.settings

logger = setup_logging(settings.log_level, config_module.CONFIG_DIR / "logs")


class BotContext:
    """
    Shared state passed to command modules. Centralizing this avoids each
    command file needing to know how to construct services itself.
    """

    def __init__(self) -> None:
        self.settings = settings
        self.node_state = NodeState.load(config_module.CONFIG_DIR)
        self.docker_manager = DockerManager()
        self.central_client = CentralClient(settings.central_url, settings.allow_insecure_http)
        self.command_dispatcher = CommandDispatcher(self.docker_manager)
        self.heartbeat_service = HeartbeatService(
            node_state=self.node_state,
            central_client=self.central_client,
            docker_manager=self.docker_manager,
            interval_seconds=settings.heartbeat_interval_seconds,
            on_central_state_change=self._on_central_state_change,
        )
        self.central_connection_state = "disconnected"
        self._ws_task: asyncio.Task | None = None

    def is_admin(self, user_id: int) -> bool:
        return user_id in self.settings.admin_user_ids

    async def _on_central_state_change(self, online: bool) -> None:
        logger.info("Central API reachability changed: %s", "ONLINE" if online else "OFFLINE")

    async def _set_ws_state(self, state: str) -> None:
        self.central_connection_state = state

    def _start_background_services(self, heartbeat_interval: int | None = None) -> None:
        if heartbeat_interval:
            self.heartbeat_service.interval_seconds = heartbeat_interval
        self.heartbeat_service.start()

        if self._ws_task is None or self._ws_task.done():
            self._ws_task = asyncio.create_task(self._run_ws_loop())

    async def _run_ws_loop(self) -> None:
        assert self.node_state.node_token is not None
        await self.central_client.run_command_loop(
            node_id=self.node_state.node_id,
            node_token=self.node_state.node_token,
            on_command=self.command_dispatcher.dispatch,
            on_state_change=self._set_ws_state,
        )

    async def on_paired(self, heartbeat_interval: int) -> None:
        self._start_background_services(heartbeat_interval=heartbeat_interval)

    async def on_unpaired(self) -> None:
        self.central_connection_state = "disconnected"
        await self.heartbeat_service.stop()
        if self._ws_task:
            self._ws_task.cancel()
            self._ws_task = None

    async def resume_if_already_paired(self) -> None:
        """Called on startup: if a token already exists locally, reconnect
        immediately without requiring /pair again."""
        if self.node_state.is_paired:
            logger.info("Existing pairing found for %s - resuming connection.", self.node_state.node_id)
            self._start_background_services(heartbeat_interval=self.settings.heartbeat_interval_seconds)


class RDXNodeClient(discord.Client):
    def __init__(self, bot_context: BotContext) -> None:
        intents = discord.Intents.default()
        super().__init__(intents=intents)
        self.bot_context = bot_context
        self.tree = app_commands.CommandTree(self)

    async def setup_hook(self) -> None:
        pair_cmd.register(self.tree, self.bot_context)
        status_cmd.register(self.tree, self.bot_context)
        info_cmd.register(self.tree, self.bot_context)
        unpair_cmd.register(self.tree, self.bot_context)
        await self.tree.sync()

        await self.bot_context.resume_if_already_paired()

    async def on_ready(self) -> None:
        logger.info("RDX Node Bot connected to Discord as %s", self.user)
        logger.info("Node ID: %s | Paired: %s", self.bot_context.node_state.node_id, self.bot_context.node_state.is_paired)


def main() -> None:
    bot_context = BotContext()
    client = RDXNodeClient(bot_context)

    try:
        client.run(settings.discord_token, log_handler=None)
    except discord.LoginFailure:
        logger.error("Discord login failed - check DISCORD_TOKEN.")
        sys.exit(1)
    except KeyboardInterrupt:
        logger.info("Shutting down (keyboard interrupt).")


if __name__ == "__main__":
    main()
