"""
Central API client.

Handles all HTTPS/WSS communication with the Central RDX Control API:
  - POST /api/v1/nodes/pair
  - POST /api/v1/nodes/heartbeat
  - POST /api/v1/nodes/unpair
  - WS   /api/v1/nodes/ws  (real-time commands from Central -> Node)

See API_CONTRACT.md in the project root for the full documented contract.

Security notes:
  - The pairing key is passed as a function argument and used only inside
    the single request body that needs it. It is never interpolated into a
    log message anywhere in this file.
  - The node token, once issued, is sent as a Bearer token on every
    authenticated request/connection and is likewise never logged.
"""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Optional

import aiohttp

from .system_info import SystemSnapshot
from .docker_manager import DockerStatus

logger = logging.getLogger("rdx_node.central")

PROTOCOL_VERSION = "1.0"

# Exponential backoff schedule for WebSocket reconnects, capped at 30s.
_BACKOFF_SCHEDULE = [1, 2, 4, 8, 16, 30]

CommandHandler = Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]


class CentralAPIError(Exception):
    """
    Raised for any Central API failure. `safe_message` is guaranteed not to
    contain secrets and is safe to display in Discord or logs. The full
    underlying exception (if any) is available via __cause__.
    """

    def __init__(self, safe_message: str):
        super().__init__(safe_message)
        self.safe_message = safe_message


class CentralClient:
    def __init__(self, base_url: str, allow_insecure_http: bool = False):
        if base_url.startswith("http://") and not allow_insecure_http:
            raise ValueError("Refusing to use insecure HTTP CENTRAL_URL without ALLOW_INSECURE_HTTP=true")
        self.base_url = base_url.rstrip("/")
        self._session: Optional[aiohttp.ClientSession] = None
        self._ws: Optional[aiohttp.ClientWebSocketSession] = None
        self._ws_task: Optional[asyncio.Task] = None
        self._closing = False

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=15),
                headers={"User-Agent": "rdx-node-bot/1.0"},
            )
        return self._session

    async def close(self) -> None:
        self._closing = True
        if self._ws_task:
            self._ws_task.cancel()
        if self._ws and not self._ws.closed:
            await self._ws.close()
        if self._session and not self._session.closed:
            await self._session.close()

    # ------------------------------------------------------------------
    # REST calls
    # ------------------------------------------------------------------

    async def pair(
        self,
        *,
        node_id: str,
        pairing_key: str,
        node_name: str,
        system_snapshot: SystemSnapshot,
        docker_status: DockerStatus,
    ) -> dict[str, Any]:
        session = await self._get_session()
        body = {
            "protocol_version": PROTOCOL_VERSION,
            "node_id": node_id,
            "pairing_key": pairing_key,
            "node_name": node_name,
            "host_info": system_snapshot.to_dict(),
            "docker_status": {
                "available": docker_status.available,
                "daemon_running": docker_status.daemon_running,
                "version": docker_status.version,
            },
        }
        try:
            async with session.post(f"{self.base_url}/api/v1/nodes/pair", json=body) as resp:
                data = await _safe_json(resp)
                if resp.status == 200:
                    return data
                raise CentralAPIError(_error_message_for(resp.status, data))
        except aiohttp.ClientError as exc:
            raise CentralAPIError("Could not reach Central API. Check CENTRAL_URL and network connectivity.") from exc

    async def unpair(self, *, node_id: str, node_token: str) -> None:
        session = await self._get_session()
        try:
            async with session.post(
                f"{self.base_url}/api/v1/nodes/unpair",
                json={"protocol_version": PROTOCOL_VERSION, "node_id": node_id},
                headers=_auth_header(node_token),
            ) as resp:
                if resp.status not in (200, 204):
                    data = await _safe_json(resp)
                    raise CentralAPIError(_error_message_for(resp.status, data))
        except aiohttp.ClientError as exc:
            raise CentralAPIError("Could not reach Central API to unpair.") from exc

    async def heartbeat(self, *, node_id: str, node_token: str, payload: dict[str, Any]) -> dict[str, Any]:
        session = await self._get_session()
        body = {"protocol_version": PROTOCOL_VERSION, "node_id": node_id, **payload}
        try:
            async with session.post(
                f"{self.base_url}/api/v1/nodes/heartbeat",
                json=body,
                headers=_auth_header(node_token),
            ) as resp:
                data = await _safe_json(resp)
                if resp.status == 200:
                    return data
                raise CentralAPIError(_error_message_for(resp.status, data))
        except aiohttp.ClientError as exc:
            raise CentralAPIError("Heartbeat request failed (network error).") from exc

    # ------------------------------------------------------------------
    # WebSocket (real-time commands)
    # ------------------------------------------------------------------

    def ws_url(self) -> str:
        if self.base_url.startswith("https://"):
            return "wss://" + self.base_url[len("https://"):] + "/api/v1/nodes/ws"
        if self.base_url.startswith("http://"):
            return "ws://" + self.base_url[len("http://"):] + "/api/v1/nodes/ws"
        return self.base_url + "/api/v1/nodes/ws"

    async def run_command_loop(
        self,
        *,
        node_id: str,
        node_token: str,
        on_command: CommandHandler,
        on_state_change: Callable[[str], Awaitable[None]],
    ) -> None:
        """
        Connects to the Central API's WebSocket endpoint and dispatches
        incoming commands to `on_command`. Reconnects automatically with
        exponential backoff (1s, 2s, 4s, 8s, 16s, 30s max) on any
        disconnect. Never requires re-pairing - the node_token remains
        valid across reconnects.
        """
        backoff_index = 0
        session = await self._get_session()

        while not self._closing:
            try:
                await on_state_change("connecting")
                async with session.ws_connect(
                    self.ws_url(),
                    headers=_auth_header(node_token),
                    heartbeat=30,
                ) as ws:
                    self._ws = ws
                    backoff_index = 0  # reset backoff after a successful connect
                    await on_state_change("connected")
                    await ws.send_json({"type": "hello", "node_id": node_id, "protocol_version": PROTOCOL_VERSION})

                    async for msg in ws:
                        if msg.type == aiohttp.WSMsgType.TEXT:
                            await self._handle_incoming(msg.data, ws, on_command)
                        elif msg.type in (aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR):
                            break

            except (aiohttp.ClientError, asyncio.TimeoutError, OSError) as exc:
                logger.warning("WebSocket connection lost: %s", exc)

            if self._closing:
                break

            await on_state_change("disconnected")
            delay = _BACKOFF_SCHEDULE[min(backoff_index, len(_BACKOFF_SCHEDULE) - 1)]
            logger.info("Reconnecting to Central API in %ss...", delay)
            await asyncio.sleep(delay)
            backoff_index += 1

    async def _handle_incoming(self, raw: str, ws: aiohttp.ClientWebSocketResponse, on_command: CommandHandler) -> None:
        try:
            message = json.loads(raw)
        except json.JSONDecodeError:
            logger.warning("Received malformed WebSocket message (not JSON); ignoring.")
            return

        msg_type = message.get("type")
        request_id = message.get("request_id")

        if not msg_type or not isinstance(msg_type, str):
            logger.warning("Received command with missing/invalid type; ignoring.")
            return

        try:
            result = await on_command(message)
        except Exception as exc:  # noqa: BLE001 - convert any handler failure into a safe error result
            logger.exception("Error handling command %s", msg_type)
            result = {"ok": False, "error": "internal_error", "detail": str(exc)}

        response = {
            "type": f"{msg_type}.result",
            "request_id": request_id,
            "result": result,
        }
        await ws.send_json(response)


def _auth_header(node_token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {node_token}"}


async def _safe_json(resp: aiohttp.ClientResponse) -> dict[str, Any]:
    try:
        return await resp.json()
    except (aiohttp.ContentTypeError, json.JSONDecodeError):
        return {}


def _error_message_for(status: int, data: dict[str, Any]) -> str:
    # Never surface raw server error bodies (could leak internal details).
    # Map known statuses to safe, generic messages.
    server_code = data.get("error_code") if isinstance(data, dict) else None
    if status == 401:
        return "Invalid or expired pairing key / node token."
    if status == 404:
        return "Central API endpoint not found. Check CENTRAL_URL."
    if status == 409:
        return "This node ID is already paired on the Central API."
    if status >= 500:
        return "Central API encountered an internal error. Try again later."
    if server_code:
        return f"Central API rejected the request ({server_code})."
    return f"Central API rejected the request (HTTP {status})."
