"""
Command dispatcher.

Every command that arrives over the Central API WebSocket connection passes
through here. This is the single choke point that decides what the Node Bot
is allowed to do on behalf of the Central Bot - it never executes arbitrary
shell commands, and it never accepts an operation that isn't on the
whitelist below.

Wire format (see API_CONTRACT.md):
{
  "type": "docker.create",
  "request_id": "...",
  "payload": { ... }
}

Response (sent back over the same WebSocket by central_client.py):
{
  "type": "docker.create.result",
  "request_id": "...",
  "result": { "ok": true, ... } | { "ok": false, "error": "...", "detail": "..." }
}
"""

from __future__ import annotations

import logging
from typing import Any, Callable

from .docker_manager import DockerManager, DockerValidationError

logger = logging.getLogger("rdx_node.dispatcher")


class CommandDispatcher:
    def __init__(self, docker_manager: DockerManager):
        self.docker_manager = docker_manager
        self._handlers: dict[str, Callable[[dict[str, Any]], dict[str, Any]]] = {
            "GET_NODE_STATUS": self._handle_get_node_status,
            "GET_NODE_STATS": self._handle_get_node_stats,
            "LIST_CONTAINERS": self._handle_list_containers,
            "CREATE_CONTAINER": self._handle_create_container,
            "START_CONTAINER": self._handle_start_container,
            "STOP_CONTAINER": self._handle_stop_container,
            "RESTART_CONTAINER": self._handle_restart_container,
            "DELETE_CONTAINER": self._handle_delete_container,
            "GET_CONTAINER_INFO": self._handle_get_container_info,
            "GET_CONTAINER_LOGS": self._handle_get_container_logs,
            "GET_CONTAINER_STATS": self._handle_get_container_stats,
            # docker.* aliases matching the example in the spec / API contract
            "docker.status": self._handle_get_node_status,
            "docker.list": self._handle_list_containers,
            "docker.create": self._handle_create_container,
            "docker.start": self._handle_start_container,
            "docker.stop": self._handle_stop_container,
            "docker.restart": self._handle_restart_container,
            "docker.delete": self._handle_delete_container,
            "docker.inspect": self._handle_get_container_info,
            "docker.logs": self._handle_get_container_logs,
            "docker.stats": self._handle_get_container_stats,
        }

    async def dispatch(self, message: dict[str, Any]) -> dict[str, Any]:
        command_type = message.get("type", "")
        payload = message.get("payload") or {}

        handler = self._handlers.get(command_type)
        if handler is None:
            logger.warning("Rejected unknown/unsupported command type: %s", command_type)
            return {"ok": False, "error": "unsupported_command", "detail": f"'{command_type}' is not a recognized command."}

        if not isinstance(payload, dict):
            return {"ok": False, "error": "invalid_payload", "detail": "payload must be an object."}

        try:
            data = handler(payload)
            return {"ok": True, "data": data}
        except DockerValidationError as exc:
            return {"ok": False, "error": "validation_error", "detail": str(exc)}
        except Exception as exc:  # noqa: BLE001
            logger.exception("Unexpected error handling command %s", command_type)
            return {"ok": False, "error": "internal_error", "detail": "An internal error occurred."}

    # ------------------------------------------------------------------
    # Individual handlers - thin wrappers around DockerManager, each
    # responsible only for pulling required fields out of the payload.
    # ------------------------------------------------------------------

    def _handle_get_node_status(self, payload: dict[str, Any]) -> dict[str, Any]:
        status = self.docker_manager.docker_status()
        return {
            "available": status.available,
            "daemon_running": status.daemon_running,
            "version": status.version,
            "container_count": status.container_count,
        }

    def _handle_get_node_stats(self, payload: dict[str, Any]) -> dict[str, Any]:
        from .system_info import get_system_snapshot

        return get_system_snapshot().to_dict()

    def _handle_list_containers(self, payload: dict[str, Any]) -> dict[str, Any]:
        return {"containers": self.docker_manager.list_containers()}

    def _handle_create_container(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.docker_manager.create_container(payload)

    def _handle_start_container(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.docker_manager.start_container(self._require(payload, "container_id"))

    def _handle_stop_container(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.docker_manager.stop_container(
            self._require(payload, "container_id"), timeout=int(payload.get("timeout", 10))
        )

    def _handle_restart_container(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.docker_manager.restart_container(
            self._require(payload, "container_id"), timeout=int(payload.get("timeout", 10))
        )

    def _handle_delete_container(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.docker_manager.delete_container(
            self._require(payload, "container_id"), force=bool(payload.get("force", False))
        )

    def _handle_get_container_info(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.docker_manager.inspect_container(self._require(payload, "container_id"))

    def _handle_get_container_logs(self, payload: dict[str, Any]) -> dict[str, Any]:
        logs = self.docker_manager.container_logs(
            self._require(payload, "container_id"), tail=int(payload.get("tail", 200))
        )
        return {"logs": logs}

    def _handle_get_container_stats(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.docker_manager.container_stats(self._require(payload, "container_id"))

    @staticmethod
    def _require(payload: dict[str, Any], field: str) -> str:
        value = payload.get(field)
        if not value or not isinstance(value, str):
            raise DockerValidationError(f"Missing required field: {field}")
        return value
