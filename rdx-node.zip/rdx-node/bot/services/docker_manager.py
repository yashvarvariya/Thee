"""
Safe Docker manager.

This module is the ONLY place in the codebase that talks to the Docker
daemon. It exposes a fixed set of high-level operations and deliberately
does NOT expose arbitrary shell/command execution inside containers or on
the host. Every operation validates its inputs before touching Docker.

Supported operations map directly to the commands the Central API is
allowed to send (see docs in the project README / API contract):

    docker_status, docker_version, list_containers, create_container,
    start_container, stop_container, restart_container, delete_container,
    inspect_container, container_logs, container_stats
"""

from __future__ import annotations

import logging
import platform
import re
import shutil
import subprocess
from dataclasses import dataclass
from typing import Any, Optional

import docker
from docker.errors import APIError, DockerException, NotFound

logger = logging.getLogger("rdx_node.docker")

# Container names created via this manager are constrained to a safe
# character set to avoid any ambiguity being passed to the Docker API.
_NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_.-]{1,62}$")

# Only images from these registries/prefixes are permitted by default.
# The Central API is expected to pass fully-qualified, already-vetted image
# references; this is a defense-in-depth allowlist, not the only check.
_DEFAULT_ALLOWED_IMAGE_PREFIXES = ("itzg/", "ghcr.io/", "docker.io/", "")


class DockerValidationError(ValueError):
    """Raised when a request payload fails validation before reaching Docker."""


@dataclass
class DockerStatus:
    available: bool
    daemon_running: bool
    version: Optional[str]
    container_count: int
    error: Optional[str] = None


class DockerManager:
    def __init__(self) -> None:
        self._client: Optional[docker.DockerClient] = None

    # ------------------------------------------------------------------
    # Connection / status
    # ------------------------------------------------------------------

    def _get_client(self) -> docker.DockerClient:
        if self._client is None:
            self._client = docker.from_env()
        return self._client

    def docker_status(self) -> DockerStatus:
        try:
            client = self._get_client()
            client.ping()
            version = client.version().get("Version")
            count = len(client.containers.list(all=True))
            return DockerStatus(
                available=True, daemon_running=True, version=version, container_count=count
            )
        except DockerException as exc:
            logger.warning("Docker status check failed: %s", exc)
            return DockerStatus(
                available=False, daemon_running=False, version=None, container_count=0, error=str(exc)
            )

    def docker_version(self) -> Optional[str]:
        try:
            return self._get_client().version().get("Version")
        except DockerException as exc:
            logger.warning("Could not fetch docker version: %s", exc)
            return None

    @staticmethod
    def is_docker_installed() -> bool:
        return shutil.which("docker") is not None

    # ------------------------------------------------------------------
    # Container operations (whitelisted set only)
    # ------------------------------------------------------------------

    def list_containers(self) -> list[dict[str, Any]]:
        client = self._get_client()
        result = []
        for c in client.containers.list(all=True):
            result.append(
                {
                    "id": c.short_id,
                    "name": c.name,
                    "status": c.status,
                    "image": c.image.tags[0] if c.image.tags else c.image.short_id,
                }
            )
        return result

    def create_container(self, payload: dict[str, Any]) -> dict[str, Any]:
        name = self._validate_name(payload.get("name"))
        image = self._validate_image(payload.get("image"))
        cpu = self._validate_positive_number(payload.get("cpu"), "cpu")
        ram_mb = self._validate_positive_number(payload.get("ram"), "ram")
        disk_gb = payload.get("disk")

        env = payload.get("env") or {}
        if not isinstance(env, dict):
            raise DockerValidationError("env must be an object of key/value strings")

        ports = payload.get("ports") or {}
        if not isinstance(ports, dict):
            raise DockerValidationError("ports must be an object")

        client = self._get_client()

        nano_cpus = int(cpu * 1_000_000_000)
        mem_limit = f"{int(ram_mb)}m"

        try:
            container = client.containers.create(
                image=image,
                name=name,
                environment={str(k): str(v) for k, v in env.items()},
                ports=ports or None,
                nano_cpus=nano_cpus,
                mem_limit=mem_limit,
                detach=True,
                restart_policy={"Name": "unless-stopped"},
                labels={"rdx.managed": "true"},
            )
        except APIError as exc:
            raise DockerValidationError(f"Docker rejected container creation: {exc}") from exc

        logger.info("Created container %s (%s) image=%s", name, container.short_id, image)
        return {"id": container.short_id, "name": name, "status": "created", "disk_gb": disk_gb}

    def start_container(self, container_id: str) -> dict[str, Any]:
        container = self._get_owned_container(container_id)
        container.start()
        logger.info("Started container %s", container_id)
        return {"id": container_id, "status": "started"}

    def stop_container(self, container_id: str, timeout: int = 10) -> dict[str, Any]:
        container = self._get_owned_container(container_id)
        container.stop(timeout=timeout)
        logger.info("Stopped container %s", container_id)
        return {"id": container_id, "status": "stopped"}

    def restart_container(self, container_id: str, timeout: int = 10) -> dict[str, Any]:
        container = self._get_owned_container(container_id)
        container.restart(timeout=timeout)
        logger.info("Restarted container %s", container_id)
        return {"id": container_id, "status": "restarted"}

    def delete_container(self, container_id: str, force: bool = False) -> dict[str, Any]:
        container = self._get_owned_container(container_id)
        container.remove(force=force)
        logger.info("Deleted container %s", container_id)
        return {"id": container_id, "status": "deleted"}

    def inspect_container(self, container_id: str) -> dict[str, Any]:
        container = self._get_owned_container(container_id)
        container.reload()
        return {
            "id": container.short_id,
            "name": container.name,
            "status": container.status,
            "image": container.image.tags[0] if container.image.tags else container.image.short_id,
            "created": container.attrs.get("Created"),
        }

    def container_logs(self, container_id: str, tail: int = 200) -> str:
        container = self._get_owned_container(container_id)
        tail = max(1, min(tail, 2000))  # clamp to a sane range
        raw = container.logs(tail=tail, timestamps=True)
        return raw.decode("utf-8", errors="replace")

    def container_stats(self, container_id: str) -> dict[str, Any]:
        container = self._get_owned_container(container_id)
        stats = container.stats(stream=False)
        cpu_delta = (
            stats["cpu_stats"]["cpu_usage"]["total_usage"]
            - stats["precpu_stats"]["cpu_usage"]["total_usage"]
        )
        system_delta = (
            stats["cpu_stats"].get("system_cpu_usage", 0)
            - stats["precpu_stats"].get("system_cpu_usage", 0)
        )
        cpu_percent = 0.0
        if system_delta > 0 and cpu_delta > 0:
            online_cpus = stats["cpu_stats"].get("online_cpus", 1)
            cpu_percent = (cpu_delta / system_delta) * online_cpus * 100.0

        mem_usage = stats.get("memory_stats", {}).get("usage", 0)
        mem_limit = stats.get("memory_stats", {}).get("limit", 1)

        return {
            "cpu_percent": round(cpu_percent, 2),
            "mem_usage_mb": round(mem_usage / (1024 * 1024), 1),
            "mem_limit_mb": round(mem_limit / (1024 * 1024), 1),
        }

    # ------------------------------------------------------------------
    # Validation helpers
    # ------------------------------------------------------------------

    def _get_owned_container(self, container_id: str):
        if not container_id or not re.match(r"^[a-zA-Z0-9]{1,64}$", container_id):
            raise DockerValidationError("Invalid container id format")
        try:
            return self._get_client().containers.get(container_id)
        except NotFound as exc:
            raise DockerValidationError(f"Container not found: {container_id}") from exc

    @staticmethod
    def _validate_name(name: Any) -> str:
        if not isinstance(name, str) or not _NAME_RE.match(name):
            raise DockerValidationError(
                "Container name must be 2-63 chars, alphanumeric plus '_.-', "
                "starting with an alphanumeric character."
            )
        return name

    @staticmethod
    def _validate_image(image: Any) -> str:
        if not isinstance(image, str) or not image.strip():
            raise DockerValidationError("Image reference is required")
        if not any(image.startswith(prefix) or "/" in image or ":" in image for prefix in _DEFAULT_ALLOWED_IMAGE_PREFIXES):
            raise DockerValidationError(f"Image reference not allowed: {image}")
        # Disallow shell metacharacters defensively even though this never
        # reaches a shell - it only ever reaches the Docker Engine API.
        if any(ch in image for ch in (";", "|", "&", "$", "`", "\n")):
            raise DockerValidationError("Image reference contains invalid characters")
        return image

    @staticmethod
    def _validate_positive_number(value: Any, field_name: str) -> float:
        try:
            number = float(value)
        except (TypeError, ValueError):
            raise DockerValidationError(f"{field_name} must be a number") from None
        if number <= 0:
            raise DockerValidationError(f"{field_name} must be greater than zero")
        return number


# ------------------------------------------------------------------
# Docker installation (Ubuntu / Debian only)
# ------------------------------------------------------------------

SUPPORTED_DISTROS = ("ubuntu", "debian")


def install_docker_if_missing(logger_: logging.Logger) -> tuple[bool, str]:
    """
    Installs Docker Engine using the official convenience script, but ONLY
    on Ubuntu/Debian, and ONLY if Docker is not already present. Returns
    (success, message). Never runs on an unsupported OS.

    This is intentionally invoked from install.sh / a one-time setup path,
    not on every bot startup, and never in response to a Discord command.
    """
    if shutil.which("docker"):
        return True, "Docker already installed."

    distro_id = _read_os_release_id()
    if distro_id not in SUPPORTED_DISTROS:
        return False, f"Unsupported OS for automatic Docker install: {distro_id or platform.system()}"

    try:
        subprocess.run(
            ["bash", "-c", "curl -fsSL https://get.docker.com | sh"],
            check=True,
            timeout=600,
        )
        subprocess.run(["systemctl", "enable", "--now", "docker"], check=True, timeout=60)
        return True, "Docker installed and started successfully."
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError) as exc:
        logger_.error("Docker installation failed: %s", exc)
        return False, f"Docker installation failed: {exc}"


def _read_os_release_id() -> Optional[str]:
    try:
        with open("/etc/os-release", encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("ID="):
                    return line.strip().split("=", 1)[1].strip('"').lower()
    except OSError:
        return None
    return None
