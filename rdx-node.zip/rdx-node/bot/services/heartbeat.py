"""
Heartbeat service.

Periodically sends resource and Docker status information to the Central
API so the panel can show live node status (online/offline, CPU/RAM/disk
usage, container count). Runs independently of the WebSocket command
channel - if the Central API is temporarily unreachable, the node keeps
retrying on the same interval rather than crashing.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Callable, Awaitable

from .central_client import CentralClient, CentralAPIError
from .docker_manager import DockerManager
from .node_identity import NodeState
from .system_info import get_system_snapshot

logger = logging.getLogger("rdx_node.heartbeat")

AGENT_VERSION = "1.0.0"

StateChangeCallback = Callable[[bool], Awaitable[None]]


class HeartbeatService:
    def __init__(
        self,
        *,
        node_state: NodeState,
        central_client: CentralClient,
        docker_manager: DockerManager,
        interval_seconds: int = 30,
        on_central_state_change: StateChangeCallback | None = None,
    ):
        self.node_state = node_state
        self.central_client = central_client
        self.docker_manager = docker_manager
        self.interval_seconds = interval_seconds
        self.on_central_state_change = on_central_state_change
        self._task: asyncio.Task | None = None
        self._running = False
        self._last_central_online: bool | None = None

    def start(self) -> None:
        if self._task is None or self._task.done():
            self._running = True
            self._task = asyncio.create_task(self._loop())

    async def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()

    def build_payload(self) -> dict:
        snapshot = get_system_snapshot()
        docker_status = self.docker_manager.docker_status()

        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "cpu_usage": snapshot.cpu_usage_percent,
            "cpu_cores": snapshot.cpu_cores,
            "ram_total": snapshot.ram_total_mb,
            "ram_used": snapshot.ram_used_mb,
            "disk_total": snapshot.disk_total_gb,
            "disk_used": snapshot.disk_used_gb,
            "docker_status": "online" if docker_status.daemon_running else "offline",
            "container_count": docker_status.container_count,
            "os": snapshot.os_name,
            "agent_version": AGENT_VERSION,
        }

    async def _loop(self) -> None:
        while self._running:
            if self.node_state.is_paired and self.node_state.node_token:
                await self._send_once()
            await asyncio.sleep(self.interval_seconds)

    async def _send_once(self) -> None:
        payload = self.build_payload()
        try:
            await self.central_client.heartbeat(
                node_id=self.node_state.node_id,
                node_token=self.node_state.node_token,  # type: ignore[arg-type]
                payload=payload,
            )
            await self._report_central_state(True)
        except CentralAPIError as exc:
            logger.warning("Heartbeat failed: %s", exc.safe_message)
            await self._report_central_state(False)

    async def _report_central_state(self, online: bool) -> None:
        if online != self._last_central_online:
            self._last_central_online = online
            if self.on_central_state_change:
                await self.on_central_state_change(online)
