"""
Node identity: generates and persists a stable Node ID, and securely stores
the permanent node token issued by the Central API after pairing.

Storage format (config/identity.json):
{
  "node_id": "RDX-NODE-7F3A92",
  "created_at": "2026-08-21T12:00:00+00:00"
}

The node token is stored separately, encrypted at rest, in
config/credentials.enc (see _TokenStore below). This keeps the token out of
plaintext files and out of anything that might get logged or accidentally
committed to version control.
"""

from __future__ import annotations

import json
import logging
import os
import secrets
import stat
import string
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from cryptography.fernet import Fernet, InvalidToken

logger = logging.getLogger("rdx_node.identity")

_ID_ALPHABET = string.ascii_uppercase + string.digits


def _generate_node_id() -> str:
    suffix = "".join(secrets.choice(_ID_ALPHABET) for _ in range(6))
    return f"RDX-NODE-{suffix}"


def _restrict_permissions(path: Path) -> None:
    """Best-effort: restrict a file to owner read/write only (0600)."""
    try:
        os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        # Not fatal (e.g. unsupported filesystem) - continue anyway.
        pass


class NodeIdentity:
    """Owns the stable Node ID. Generated once, never regenerated."""

    def __init__(self, config_dir: Path):
        self.config_dir = config_dir
        self.identity_path = config_dir / "identity.json"
        self._node_id: Optional[str] = None

    def load_or_create(self) -> str:
        if self.identity_path.exists():
            try:
                data = json.loads(self.identity_path.read_text())
                node_id = data.get("node_id")
                if node_id:
                    self._node_id = node_id
                    return node_id
            except (json.JSONDecodeError, OSError) as exc:
                logger.warning("Could not read existing identity file, regenerating: %s", exc)

        node_id = _generate_node_id()
        self.identity_path.write_text(
            json.dumps(
                {
                    "node_id": node_id,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                },
                indent=2,
            )
        )
        _restrict_permissions(self.identity_path)
        self._node_id = node_id
        logger.info("Generated new Node ID: %s", node_id)
        return node_id

    @property
    def node_id(self) -> Optional[str]:
        return self._node_id


class TokenStore:
    """
    Encrypts and persists the permanent node token issued by the Central API.

    The encryption key itself lives in a separate file (config/.keyfile) with
    owner-only permissions. This does not defend against a fully compromised
    host, but it keeps the token out of plaintext config files, backups made
    without the key, and accidental log/output exposure.
    """

    def __init__(self, config_dir: Path):
        self.config_dir = config_dir
        self.key_path = config_dir / ".keyfile"
        self.token_path = config_dir / "credentials.enc"
        self._fernet = Fernet(self._load_or_create_key())

    def _load_or_create_key(self) -> bytes:
        if self.key_path.exists():
            return self.key_path.read_bytes()
        key = Fernet.generate_key()
        self.key_path.write_bytes(key)
        _restrict_permissions(self.key_path)
        return key

    def save_token(self, node_token: str) -> None:
        encrypted = self._fernet.encrypt(node_token.encode("utf-8"))
        self.token_path.write_bytes(encrypted)
        _restrict_permissions(self.token_path)
        logger.info("Node token stored securely.")

    def load_token(self) -> Optional[str]:
        if not self.token_path.exists():
            return None
        try:
            encrypted = self.token_path.read_bytes()
            return self._fernet.decrypt(encrypted).decode("utf-8")
        except (InvalidToken, OSError) as exc:
            logger.error("Failed to decrypt stored node token: %s", exc)
            return None

    def clear_token(self) -> None:
        if self.token_path.exists():
            try:
                self.token_path.unlink()
            except OSError as exc:
                logger.warning("Could not remove stored token file: %s", exc)
        logger.info("Node token cleared (unpaired).")

    def has_token(self) -> bool:
        return self.token_path.exists()


@dataclass
class NodeState:
    """Runtime state combining identity + token + pairing status."""

    identity: NodeIdentity
    token_store: TokenStore
    node_token: Optional[str] = None

    @classmethod
    def load(cls, config_dir: Path) -> "NodeState":
        identity = NodeIdentity(config_dir)
        identity.load_or_create()
        token_store = TokenStore(config_dir)
        node_token = token_store.load_token()
        return cls(identity=identity, token_store=token_store, node_token=node_token)

    @property
    def node_id(self) -> str:
        assert self.identity.node_id is not None
        return self.identity.node_id

    @property
    def is_paired(self) -> bool:
        return self.node_token is not None

    def apply_pairing_result(self, node_token: str) -> None:
        self.token_store.save_token(node_token)
        self.node_token = node_token

    def unpair(self) -> None:
        self.token_store.clear_token()
        self.node_token = None
