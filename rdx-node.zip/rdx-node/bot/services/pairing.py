"""
Pairing service.

Handles the one-time pairing handshake with the Central RDX Control API.
The pairing key entered by an administrator is used exactly once, sent
directly to the Central API over HTTPS, and never written to disk or logs.
On success, the returned permanent node token is handed to NodeState /
TokenStore for encrypted local storage.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

from .central_client import CentralClient, CentralAPIError
from .docker_manager import DockerManager
from .node_identity import NodeState
from .system_info import get_system_snapshot

logger = logging.getLogger("rdx_node.pairing")


@dataclass
class PairingResult:
    success: bool
    node_id: Optional[str] = None
    heartbeat_interval: Optional[int] = None
    message: str = ""


class PairingError(Exception):
    """Raised for any pairing failure. Message is always safe to show the user."""


async def pair_node(
    *,
    pairing_key: str,
    node_state: NodeState,
    central_client: CentralClient,
    docker_manager: DockerManager,
    node_name: str,
) -> PairingResult:
    """
    Executes the full pairing flow. `pairing_key` is used only in-memory for
    this call and is never logged or persisted (see central_client.py for
    the request-building logic that keeps it out of log statements).
    """
    if not pairing_key or not pairing_key.strip():
        raise PairingError("Pairing key cannot be empty.")

    pairing_key = pairing_key.strip()

    if node_state.is_paired:
        raise PairingError("This node is already paired. Use /unpair first if you want to re-pair.")

    snapshot = get_system_snapshot()
    docker_status = docker_manager.docker_status()

    try:
        response = await central_client.pair(
            node_id=node_state.node_id,
            pairing_key=pairing_key,
            node_name=node_name,
            system_snapshot=snapshot,
            docker_status=docker_status,
        )
    except CentralAPIError as exc:
        logger.warning("Pairing failed for node %s: %s", node_state.node_id, exc.safe_message)
        return PairingResult(success=False, message=exc.safe_message)

    node_token = response.get("node_token")
    if not node_token:
        return PairingResult(success=False, message="Central API did not return a node token.")

    node_state.apply_pairing_result(node_token)
    heartbeat_interval = response.get("heartbeat_interval", 30)

    logger.info("Node %s paired successfully.", node_state.node_id)
    return PairingResult(
        success=True,
        node_id=node_state.node_id,
        heartbeat_interval=heartbeat_interval,
        message="Node paired successfully.",
    )


async def unpair_node(*, node_state: NodeState, central_client: CentralClient) -> bool:
    """Notifies the Central API and clears the local token regardless of the
    API call's outcome, so a node can always be reset locally."""
    try:
        if node_state.node_token:
            await central_client.unpair(node_id=node_state.node_id, node_token=node_state.node_token)
    except CentralAPIError as exc:
        logger.warning("Central API unpair call failed (clearing local state anyway): %s", exc.safe_message)
    finally:
        node_state.unpair()
    return True
