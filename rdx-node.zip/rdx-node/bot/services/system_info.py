"""
Collects host resource information (CPU, RAM, disk, OS, kernel) using psutil
and the platform module. Used for pairing payloads, heartbeats, and the
/info and /status Discord commands.
"""

from __future__ import annotations

import platform
from dataclasses import dataclass, asdict

import psutil


@dataclass
class SystemSnapshot:
    os_name: str
    os_version: str
    kernel_version: str
    cpu_cores: int
    cpu_usage_percent: float
    ram_total_mb: int
    ram_used_mb: int
    ram_available_mb: int
    disk_total_gb: float
    disk_used_gb: float
    disk_available_gb: float

    def to_dict(self) -> dict:
        return asdict(self)


def detect_os() -> tuple[str, str]:
    """Return (distro_name, version) e.g. ('Ubuntu', '22.04')."""
    try:
        os_release = platform.freedesktop_os_release()
        name = os_release.get("NAME", platform.system())
        version = os_release.get("VERSION_ID", platform.release())
        return name, version
    except (OSError, AttributeError):
        return platform.system(), platform.release()


def is_supported_os() -> bool:
    name, _ = detect_os()
    return name.lower() in ("ubuntu", "debian", "debian gnu/linux")


def get_system_snapshot() -> SystemSnapshot:
    os_name, os_version = detect_os()
    vm = psutil.virtual_memory()
    disk = psutil.disk_usage("/")

    return SystemSnapshot(
        os_name=os_name,
        os_version=os_version,
        kernel_version=platform.release(),
        cpu_cores=psutil.cpu_count(logical=True) or 0,
        cpu_usage_percent=psutil.cpu_percent(interval=0.5),
        ram_total_mb=round(vm.total / (1024 * 1024)),
        ram_used_mb=round(vm.used / (1024 * 1024)),
        ram_available_mb=round(vm.available / (1024 * 1024)),
        disk_total_gb=round(disk.total / (1024 ** 3), 1),
        disk_used_gb=round(disk.used / (1024 ** 3), 1),
        disk_available_gb=round(disk.free / (1024 ** 3), 1),
    )
