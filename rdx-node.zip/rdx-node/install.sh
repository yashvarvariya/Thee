#!/usr/bin/env bash
#
# RDX Node Bot installer
#
# Usage:
#   curl -fsSL https://YOUR_DOMAIN/install.sh | bash
#   or: bash install.sh
#
# Supported OS: Ubuntu, Debian
#
set -euo pipefail

INSTALL_DIR="/opt/rdx-node"
SERVICE_USER="rdxnode"
SERVICE_NAME="rdx-node"
REPO_SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

log()  { echo -e "\033[1;34m[rdx-node]\033[0m $*"; }
warn() { echo -e "\033[1;33m[rdx-node]\033[0m $*"; }
die()  { echo -e "\033[1;31m[rdx-node] ERROR:\033[0m $*" >&2; exit 1; }

require_root() {
    if [[ "$(id -u)" -ne 0 ]]; then
        die "This installer must be run as root (use sudo)."
    fi
}

# ---------------------------------------------------------------------
# 1. Detect OS
# ---------------------------------------------------------------------
detect_os() {
    if [[ ! -f /etc/os-release ]]; then
        die "Cannot detect OS (missing /etc/os-release). Unsupported system."
    fi
    # shellcheck disable=SC1091
    . /etc/os-release
    DISTRO_ID="${ID:-unknown}"
    DISTRO_VERSION="${VERSION_ID:-unknown}"

    case "$DISTRO_ID" in
        ubuntu|debian)
            log "Detected supported OS: $NAME $DISTRO_VERSION"
            ;;
        *)
            die "❌ Unsupported OS: $NAME. This installer supports Ubuntu and Debian only."
            ;;
    esac
}

# ---------------------------------------------------------------------
# 2. Install required OS dependencies
# ---------------------------------------------------------------------
install_dependencies() {
    log "Updating package lists and installing base dependencies..."
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -y
    apt-get install -y --no-install-recommends \
        ca-certificates curl gnupg python3 python3-venv python3-pip
}

# ---------------------------------------------------------------------
# 3. Install Docker if missing
# ---------------------------------------------------------------------
install_docker_if_missing() {
    if command -v docker >/dev/null 2>&1; then
        log "Docker already installed: $(docker --version)"
    else
        log "Docker not found. Installing via get.docker.com..."
        curl -fsSL https://get.docker.com | sh
        systemctl enable --now docker
    fi

    if ! systemctl is-active --quiet docker; then
        systemctl enable --now docker
    fi

    if docker info >/dev/null 2>&1; then
        log "Docker daemon verified: OK"
    else
        die "Docker installed but the daemon is not responding. Check 'systemctl status docker'."
    fi
}

# ---------------------------------------------------------------------
# 4. Create service user
# ---------------------------------------------------------------------
create_service_user() {
    if id "$SERVICE_USER" >/dev/null 2>&1; then
        log "Service user '$SERVICE_USER' already exists."
    else
        log "Creating dedicated service user '$SERVICE_USER'..."
        useradd --system --create-home --shell /usr/sbin/nologin "$SERVICE_USER"
    fi

    if ! getent group docker >/dev/null 2>&1; then
        groupadd docker
    fi
    usermod -aG docker "$SERVICE_USER"
}

# ---------------------------------------------------------------------
# 5. Install project files
# ---------------------------------------------------------------------
install_project_files() {
    log "Installing RDX Node Bot to $INSTALL_DIR..."
    mkdir -p "$INSTALL_DIR"
    cp -r "$REPO_SOURCE_DIR"/bot "$INSTALL_DIR"/
    cp -r "$REPO_SOURCE_DIR"/requirements.txt "$INSTALL_DIR"/
    mkdir -p "$INSTALL_DIR/config"

    if [[ ! -f "$INSTALL_DIR/.env" ]]; then
        cp "$REPO_SOURCE_DIR/.env.example" "$INSTALL_DIR/.env"
        warn "Created $INSTALL_DIR/.env from template - EDIT THIS before pairing."
        warn "At minimum set CENTRAL_URL, DISCORD_TOKEN, and ADMIN_USER_IDS."
    fi

    chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"
    chmod 700 "$INSTALL_DIR/config"
}

# ---------------------------------------------------------------------
# 6. Python virtual environment + dependencies
# ---------------------------------------------------------------------
setup_python_env() {
    log "Creating Python virtual environment..."
    sudo -u "$SERVICE_USER" python3 -m venv "$INSTALL_DIR/venv"
    sudo -u "$SERVICE_USER" "$INSTALL_DIR/venv/bin/pip" install --upgrade pip
    sudo -u "$SERVICE_USER" "$INSTALL_DIR/venv/bin/pip" install -r "$INSTALL_DIR/requirements.txt"
}

# ---------------------------------------------------------------------
# 7. Install systemd service
# ---------------------------------------------------------------------
install_systemd_service() {
    log "Installing systemd service..."
    cp "$REPO_SOURCE_DIR/systemd/rdx-node.service" "/etc/systemd/system/${SERVICE_NAME}.service"
    systemctl daemon-reload
    systemctl enable "$SERVICE_NAME"
}

# ---------------------------------------------------------------------
# 8. Start the Node Bot (only if configured)
# ---------------------------------------------------------------------
start_service_if_configured() {
    if grep -q '^DISCORD_TOKEN=$' "$INSTALL_DIR/.env" 2>/dev/null || grep -q '^DISCORD_TOKEN=\s*$' "$INSTALL_DIR/.env" 2>/dev/null; then
        warn "DISCORD_TOKEN is not set yet - not starting the service automatically."
        warn "Edit $INSTALL_DIR/.env, then run: systemctl start $SERVICE_NAME"
        return
    fi
    log "Starting $SERVICE_NAME..."
    systemctl restart "$SERVICE_NAME"
    sleep 2
    systemctl --no-pager status "$SERVICE_NAME" || true
}

print_summary() {
    local cpu_cores ram_gb
    cpu_cores=$(nproc)
    ram_gb=$(awk '/MemTotal/ {printf "%.0f", $2/1024/1024}' /proc/meminfo)

    echo ""
    echo "================================"
    echo "RDX NODE INSTALLATION COMPLETE"
    echo "================================"
    echo ""
    echo "Install directory:"
    echo "  $INSTALL_DIR"
    echo ""
    echo "Node ID:"
    echo "  (generated on first bot startup - check with: journalctl -u $SERVICE_NAME -n 20)"
    echo ""
    echo "Docker:"
    echo "  ONLINE"
    echo ""
    echo "CPU:"
    echo "  $cpu_cores cores"
    echo ""
    echo "RAM:"
    echo "  ${ram_gb} GB"
    echo ""
    echo "Status:"
    echo "  WAITING FOR PAIRING"
    echo ""
    echo "Next step:"
    echo "  1. Edit $INSTALL_DIR/.env with your CENTRAL_URL, DISCORD_TOKEN, and ADMIN_USER_IDS"
    echo "  2. Run: systemctl restart $SERVICE_NAME"
    echo "  3. Open the RDX Node Bot in Discord and use: /pair"
    echo "  4. Enter the pairing key generated by the Central RDX Bot."
    echo ""
    echo "================================"
}

main() {
    require_root
    detect_os
    install_dependencies
    install_docker_if_missing
    create_service_user
    install_project_files
    setup_python_env
    install_systemd_service
    start_service_if_configured
    print_summary
}

main "$@"
