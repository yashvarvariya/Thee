"""
Minimal local mock of the Central RDX Control API, implementing the
contract documented in API_CONTRACT.md. Useful for manually testing the
Node Bot end-to-end without a real Central Bot.

Run:
    pip install aiohttp
    python tests/mock_central_server.py

Then set CENTRAL_URL=http://127.0.0.1:8765 and ALLOW_INSECURE_HTTP=true in
your .env, and use pairing key "TEST-KEY-1234" with /pair.
"""

from __future__ import annotations

import secrets
import uuid

from aiohttp import web

VALID_PAIRING_KEYS = {"TEST-KEY-1234"}
PAIRED_NODES: dict[str, dict] = {}


def _auth_ok(request: web.Request, node_id: str) -> bool:
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return False
    token = auth[len("Bearer "):]
    node = PAIRED_NODES.get(node_id)
    return bool(node) and node.get("token") == token


async def handle_pair(request: web.Request) -> web.Response:
    body = await request.json()
    node_id = body.get("node_id")
    pairing_key = body.get("pairing_key")

    if pairing_key not in VALID_PAIRING_KEYS:
        return web.json_response({"error_code": "invalid_pairing_key"}, status=401)

    if node_id in PAIRED_NODES:
        return web.json_response({"error_code": "already_paired"}, status=409)

    token = secrets.token_urlsafe(32)
    PAIRED_NODES[node_id] = {"token": token, "name": body.get("node_name")}
    VALID_PAIRING_KEYS.discard(pairing_key)  # one-time use

    return web.json_response(
        {
            "node_id": node_id,
            "node_token": token,
            "heartbeat_interval": 10,
            "configuration": {},
        }
    )


async def handle_heartbeat(request: web.Request) -> web.Response:
    body = await request.json()
    node_id = body.get("node_id")
    if not _auth_ok(request, node_id):
        return web.json_response({"error_code": "unauthorized"}, status=401)
    print(f"[mock-central] heartbeat from {node_id}: cpu={body.get('cpu_usage')}% "
          f"ram={body.get('ram_used')}/{body.get('ram_total')}MB "
          f"docker={body.get('docker_status')}")
    return web.json_response({"acknowledged": True})


async def handle_unpair(request: web.Request) -> web.Response:
    body = await request.json()
    node_id = body.get("node_id")
    if not _auth_ok(request, node_id):
        return web.json_response({"error_code": "unauthorized"}, status=401)
    PAIRED_NODES.pop(node_id, None)
    return web.json_response({}, status=200)


async def handle_ws(request: web.Request) -> web.WebSocketResponse:
    ws = web.WebSocketResponse(heartbeat=30)
    await ws.prepare(request)

    async for msg in ws:
        if msg.type == web.WSMsgType.TEXT:
            data = msg.json()
            print(f"[mock-central] ws message: {data}")
            if data.get("type") == "hello":
                # Example: ask the node to list containers 2s after hello.
                await ws.send_json(
                    {"type": "LIST_CONTAINERS", "request_id": str(uuid.uuid4()), "payload": {}}
                )

    return ws


def build_app() -> web.Application:
    app = web.Application()
    app.router.add_post("/api/v1/nodes/pair", handle_pair)
    app.router.add_post("/api/v1/nodes/heartbeat", handle_heartbeat)
    app.router.add_post("/api/v1/nodes/unpair", handle_unpair)
    app.router.add_get("/api/v1/nodes/ws", handle_ws)
    return app


if __name__ == "__main__":
    print("Mock Central API listening on http://127.0.0.1:8765")
    print(f"Valid pairing key(s): {VALID_PAIRING_KEYS}")
    web.run_app(build_app(), host="127.0.0.1", port=8765)
