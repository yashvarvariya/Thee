import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from bot.services.command_dispatcher import CommandDispatcher  # noqa: E402
from bot.services.docker_manager import DockerManager  # noqa: E402


@pytest.mark.asyncio
async def test_unknown_command_rejected():
    dispatcher = CommandDispatcher(DockerManager())
    result = await dispatcher.dispatch({"type": "SSH_EXEC", "payload": {"cmd": "rm -rf /"}})
    assert result["ok"] is False
    assert result["error"] == "unsupported_command"


@pytest.mark.asyncio
async def test_non_object_payload_rejected():
    dispatcher = CommandDispatcher(DockerManager())
    result = await dispatcher.dispatch({"type": "LIST_CONTAINERS", "payload": "not-an-object"})
    assert result["ok"] is False
    assert result["error"] == "invalid_payload"


@pytest.mark.asyncio
async def test_missing_required_field_rejected():
    dispatcher = CommandDispatcher(DockerManager())
    result = await dispatcher.dispatch({"type": "START_CONTAINER", "payload": {}})
    assert result["ok"] is False
    assert result["error"] == "validation_error"


@pytest.mark.asyncio
async def test_arbitrary_shell_style_command_never_recognized():
    dispatcher = CommandDispatcher(DockerManager())
    for forbidden in ("SHELL", "EXEC", "RUN_COMMAND", "/ssh", "ssh.exec"):
        result = await dispatcher.dispatch({"type": forbidden, "payload": {}})
        assert result["ok"] is False
        assert result["error"] == "unsupported_command"
