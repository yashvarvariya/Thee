import sys
from pathlib import Path
from unittest.mock import MagicMock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from bot.services.heartbeat import HeartbeatService  # noqa: E402
from bot.services.docker_manager import DockerStatus  # noqa: E402

EXPECTED_FIELDS = {
    "timestamp", "cpu_usage", "cpu_cores", "ram_total", "ram_used",
    "disk_total", "disk_used", "docker_status", "container_count",
    "os", "agent_version",
}


def test_heartbeat_payload_has_all_required_fields():
    fake_docker_manager = MagicMock()
    fake_docker_manager.docker_status.return_value = DockerStatus(
        available=True, daemon_running=True, version="27.3.1", container_count=5
    )

    service = HeartbeatService(
        node_state=MagicMock(),
        central_client=MagicMock(),
        docker_manager=fake_docker_manager,
    )

    payload = service.build_payload()
    assert EXPECTED_FIELDS.issubset(payload.keys())
    assert payload["docker_status"] == "online"
    assert payload["container_count"] == 5


def test_heartbeat_payload_reports_offline_docker():
    fake_docker_manager = MagicMock()
    fake_docker_manager.docker_status.return_value = DockerStatus(
        available=False, daemon_running=False, version=None, container_count=0, error="no daemon"
    )

    service = HeartbeatService(
        node_state=MagicMock(),
        central_client=MagicMock(),
        docker_manager=fake_docker_manager,
    )

    payload = service.build_payload()
    assert payload["docker_status"] == "offline"
