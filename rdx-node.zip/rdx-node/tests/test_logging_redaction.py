import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from bot.logging_config import RedactSecretsFilter  # noqa: E402


def _filtered_message(msg: str) -> str:
    record = logging.LogRecord(
        name="test", level=logging.INFO, pathname=__file__, lineno=1,
        msg=msg, args=(), exc_info=None,
    )
    RedactSecretsFilter().filter(record)
    return record.getMessage()


def test_redacts_pairing_key():
    out = _filtered_message('pairing_key=RDX-7K4P-92XM received')
    assert "RDX-7K4P-92XM" not in out
    assert "[REDACTED]" in out


def test_redacts_node_token_json_style():
    out = _filtered_message('{"node_token": "abc123XYZ"}')
    assert "abc123XYZ" not in out
    assert "[REDACTED]" in out


def test_redacts_bearer_token():
    out = _filtered_message("Authorization: Bearer sk-live-abcdef123456")
    assert "sk-live-abcdef123456" not in out
    assert "[REDACTED]" in out


def test_leaves_normal_messages_untouched():
    out = _filtered_message("Node RDX-NODE-7F3A92 connected successfully")
    assert out == "Node RDX-NODE-7F3A92 connected successfully"
