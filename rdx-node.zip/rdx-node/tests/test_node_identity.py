import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from bot.services.node_identity import NodeIdentity, TokenStore, NodeState  # noqa: E402

NODE_ID_RE = re.compile(r"^RDX-NODE-[A-Z0-9]{6}$")


def test_generates_valid_node_id_format(tmp_path):
    identity = NodeIdentity(tmp_path)
    node_id = identity.load_or_create()
    assert NODE_ID_RE.match(node_id), f"Node ID '{node_id}' does not match expected format"


def test_node_id_stable_across_restarts(tmp_path):
    identity1 = NodeIdentity(tmp_path)
    first_id = identity1.load_or_create()

    # Simulate a restart: new NodeIdentity instance pointing at the same dir.
    identity2 = NodeIdentity(tmp_path)
    second_id = identity2.load_or_create()

    assert first_id == second_id


def test_identity_file_created(tmp_path):
    identity = NodeIdentity(tmp_path)
    identity.load_or_create()
    assert (tmp_path / "identity.json").exists()


def test_token_store_round_trip(tmp_path):
    store = TokenStore(tmp_path)
    assert store.load_token() is None
    assert not store.has_token()

    store.save_token("super-secret-token")
    assert store.has_token()
    assert store.load_token() == "super-secret-token"


def test_token_store_never_writes_plaintext(tmp_path):
    store = TokenStore(tmp_path)
    store.save_token("super-secret-token")
    raw = (tmp_path / "credentials.enc").read_bytes()
    assert b"super-secret-token" not in raw


def test_token_store_clear(tmp_path):
    store = TokenStore(tmp_path)
    store.save_token("abc123")
    store.clear_token()
    assert store.load_token() is None
    assert not store.has_token()


def test_node_state_load_and_pairing(tmp_path):
    state = NodeState.load(tmp_path)
    assert not state.is_paired

    state.apply_pairing_result("my-permanent-token")
    assert state.is_paired
    assert state.node_token == "my-permanent-token"

    # Reload from disk to confirm persistence.
    state2 = NodeState.load(tmp_path)
    assert state2.is_paired
    assert state2.node_token == "my-permanent-token"
    assert state2.node_id == state.node_id  # stable across reload

    state2.unpair()
    assert not state2.is_paired
